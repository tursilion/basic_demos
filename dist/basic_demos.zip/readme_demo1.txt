Unzip this file into your Classic99\DSK1 folder.
No cartridge need be selected.
Follow the menus to start TI BASIC.
Type: OLD DSK1.DEMO1
Type: RUN

In this case, you just sit and watch.

Disabling CPU throttle in options will make most
BASIC games respond better. If you get repeating
characters when typing, turn the throttle on again.
