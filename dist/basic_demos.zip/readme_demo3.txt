Unzip this file into your Classic99\DSK1 folder.
To start it, select the EXTENDED BASIC cartridge.
Follow the menus to start Extended BASIC.
Type: OLD DSK1.DEMO3
Type: RUN

In this case, you just sit and watch.
Disabling CPU throttle in options will make most
XB games respond better. If you get repeating
characters when typing, turn the throttle on again.