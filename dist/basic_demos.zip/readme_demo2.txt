Unzip this file into your Classic99\DSK1 folder.
To start it, select the EXTENDED BASIC cartridge.
Follow the menus to start Extended BASIC.
Type: OLD DSK1.DEMO2
Type: RUN

CPU throttle ENABLED.
In this case, you just sit and watch.
